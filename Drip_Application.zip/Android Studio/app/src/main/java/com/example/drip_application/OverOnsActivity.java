package com.example.drip_application;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.sax.Element;

public class OverOnsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_over_ons);


    }
}
